<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
       public function __construct() {
        parent::__construct();
        
       }
	public function index()
	{
            
	$query=$this->db->query("select * from students ");
	$get= $query->result();
        $data=array('record'=>$get );
         $this->load->view('View', $data);

	}

        public function add() {
             if($this->input->post('sname'))
                 {
                $sname= $this->input->post('sname');
                $semail = $this->input->post('semail');
                $saddress= $this->input->post('saddress');
                $data1 = array(
                    'sname' => $sname,
                    'semail' => $semail,
                    'saddress' => $saddress
                );
                $records= $this->db->insert('students', $data1);

                 $this->load->view('View');
                 redirect('Welcome/index');
          
         }   else{
             $this->load->view('studentview');
         }
        }
        
      public function edit($id=0){
            if($this->input->post('sname'))
                 {
                $sname= $this->input->post('sname');
                $semail = $this->input->post('semail');
              
                $saddress= $this->input->post('saddress');
                $data1 = array(
                    'sname' => $sname,
                    'semail' => $semail,
                    'saddress' => $saddress
                );
                
             $this->db->where('sid', $id);
               $this->db->update('students', $data1);
             
              redirect('Welcome/index');
       }
       else{
           $query=$this->db->query("select * from students where sid=$id");
	$get= $query->row();
        $data=array(
           'record'=>$get
       );
     
          $this->load->view('Edit',$data);
       }
       
     }
         public function delete($id=0){                
        $data1=array(
            'sname'=>0
        );
        
        $this->db->where('sid', $id);
         $this->db->update('students', $data1);
        redirect('Welcome/index');
         }

}

