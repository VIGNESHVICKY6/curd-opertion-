<!DOCTYPE html>
<html>
<head>
<title>Display Records</title>
</head>

<body>
    <a href="<?php echo base_url() ;?>Welcome/add">Add</a>
  
<table>
  <tr>
    <th>Id</th>
    <th>Name</th>
    <th>Email</th>
    
    <th>Address</th>
    <th>Option</th>
  </tr>
  <?php
 
  if(is_array($record)):
  foreach($record as $row)
  {
      ?>
  <tr>
  <td><?php echo $row->sid; ?></td>
  <td><?php echo $row->sname; ?></td>
  <td><?php echo $row->semail; ?></td>
  <td> <?php echo $row->saddress; ?></td>

   <td><a href="<?php echo base_url() ;?>Welcome/Edit/<?php echo $row->sid; ?>">Edit</a>
   |
   <a href="<?php echo base_url() ;?>Welcome/delete/<?php echo $row->sid; ?>">Delete</a>
   </td>
   
  <?php
 }
endif;
  ?>
</table>

</body>
</html>


