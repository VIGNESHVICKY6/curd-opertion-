
      
    
                <form action="" method="post" id="my_form" >
                <table>
                    <tbody>
                        <tr>
                            <td>
                                Name<font color="red">*</font>
                            </td>
                            <td>
                                <input type="text" name="sname" id="sname" placeholder="Enter Name" 
                                       value="" required autofocus> 
                            </td>
                        </tr>
                                  <tr>
                                      <td>
                                          Email ID<font color="red">*</font>
                                      </td>
                                      <td>
                                         <input type="text" name="semail" id="semail"  placeholder="Enter Email ID"   value="" required> 
                                      </td>
                                      
                                    
                                  </tr>
                                 
                                  <tr>
                                      <td>
                                          Address:
                                      </td>
                                      <td>
                                         <input type="text" name="saddress" id="saddress"  placeholder="Enter Address"   value=""> 
                                      </td>
                                  </tr>
                                  <tr>
                                <td class="span2"> </td>
                                <td>
                                 <button type="Submit" id="save" class="btn btn-primary btn-3d" value="Save">
                                    <i class="fa fa-save"></i> &nbsp;Save
                                  </button>
                                     <button type="Reset" class="btn btn-danger btn-3d" value="Reset">
                                     <i class="fa fa-refresh"></i> &nbsp;Reset
                                     </button>
                                </td>
                            </tr>
                            
                                  
                                </tbody>
                 </table></form>
            
        
    

			        

</body>
</html>

  