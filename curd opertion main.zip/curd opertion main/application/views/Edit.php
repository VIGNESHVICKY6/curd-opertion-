
           
    <form method="post" action= "" id="my_form"  class="form-horizontal">
                            <h3 class="panel-title"> EDIT STUDENT DETAILS OF <span><b><?php echo $record->sid ?> </b></span> </h3>
                        </div>
                    </div>
                    <table class="table table-striped table-bordered table-hover ">
                        <tbody>
                             <tr>
                            <td>
                                Name<font color="red">*</font>
                            </td>
                            <td>
                                <input type="text" name="sname" id="sname" class="form-control tabletdwd" placeholder="Enter Name"
                                       value="<?php echo $record->sname ?>" required autofocus> 
                            </td>
                        </tr>
                                  <tr>
                                      <td>
                                          Email ID<font color="red">*</font>
                                      </td>
                                      <td>
                                         <input type="text" name="semail" id="semail" class="form-control tabletdwd" placeholder="Enter Email ID"   value="<?php echo $record->semail ?>" required> 
                                      </td>
                                      
                                    
                                  </tr>
                                 
                                  <tr>
                                      <td>
                                          Address:
                                      </td>
                                      <td>
                                         <input type="text" name="saddress" id="saddress" class="form-control tabletdwd" placeholder="Enter Address"   value="<?php echo $record->saddress ?>"> 
                                      </td>
                                  </tr>
                           
                            <tr>
                                <td class="span2"> </td>
                                <td>
                                    <button type="Submit" id="save" class="btn btn-primary btn-3d" value="Save">
                                        <i class="fa fa-save"></i> &nbsp;Save
                                    </button>
                                    <button type="Reset" class="btn btn-danger btn-3d" value="Reset">
                                        <i class="fa fa-refresh"></i> &nbsp;Reset
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
               
           
       
    </form>


                