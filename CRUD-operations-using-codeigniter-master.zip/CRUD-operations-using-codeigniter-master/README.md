# CRUD operations using codeigniter
 Using student details , CRUD operations has been performed with database connectivity
