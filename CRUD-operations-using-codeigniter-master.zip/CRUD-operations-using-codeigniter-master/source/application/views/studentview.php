<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <!---breadcrumbs start --->
        <ul class="breadcrumb">
            <li class="">
       <i class="fa fa-home"></i>

                </li>
            <li>
        
                     <a href="/Employees/index">Students</a>/  Create New students
    </li>
        </ul>
        <!---breadcrumbs end --->
    </div>
</div>  


<a class="btn btn-danger btn-small" href="View" >
        <font color="white"> <i class="fa fa-reply"></i>Back to Students list  </font>
    </a>
      
    <div class="row-fluid">
        <div class="span12">
            <div class="row-fluid">
                <div class="panel panel-info">
                <div class="panel-heading">
                  <h3 class="panel-title">  ADD STUDENT DETAILS </h3>
                </div>
               
              </div>
                <form action="" method="post" id="my_form" enctype="multipart/form-data">
                <table class="table table-striped table-bordered table-hover ">
                    <tbody>
                        <tr>
                            <td>
                                Name<font color="red">*</font>
                            </td>
                            <td>
                                <input type="text" name="sname" id="sname" class="form-control tabletdwd" placeholder="Enter Name" 
                                       value="" required autofocus> 
                            </td>
                        </tr>
                                  <tr>
                                      <td>
                                          Email ID<font color="red">*</font>
                                      </td>
                                      <td>
                                         <input type="text" name="semail" id="semail" class="form-control tabletdwd" placeholder="Enter Email ID"   value="" required> 
                                      </td>
                                      
                                    
                                  </tr>
                                  <tr>
                                      <td>
                                          Mobile No:
                                      </td>
                                      <td>
                                         <input type="text" name="smobile" id="smobile" class="form-control tabletdwd" placeholder="Enter MobileNumber"   value="" > 
                                      </td>
                                  </tr>
                                  <tr>
                                      <td>
                                          Address:
                                      </td>
                                      <td>
                                         <input type="text" name="saddress" id="saddress" class="form-control tabletdwd" placeholder="Enter Address"   value=""> 
                                      </td>
                                  </tr>
                                  <tr>
                                <td class="span2"> </td>
                                <td>
                                 <button type="Submit" id="save" class="btn btn-primary btn-3d" value="Save">
                                    <i class="fa fa-save"></i> &nbsp;Save
                                  </button>
                                     <button type="Reset" class="btn btn-danger btn-3d" value="Reset">
                                     <i class="fa fa-refresh"></i> &nbsp;Reset
                                     </button>
                                </td>
                            </tr>
                            
                                  
                                </tbody>
                 </table></form>
            </div>
        </div>
    </div>

			        
</div>
</body>
</html>

  