
<html>
<head>
<title>Login Page</title>
</head>
<body>
<form name="loginForm" method="post" action="Welcome/add">
<table width="20%" align="center">

<tr>
<td colspan=2><center><font size=4><b> Login Page</b></font></center></td>
</tr>

<tr>
<td>Username:</td>
<td><input type="text" size=25 name="username"></td>
</tr>

<tr>
<td>Password:</td>
<td><input type="Password" size=25 name="password"></td>
</tr>

<tr>
<td ><input type="Reset"></td>
<td><input type="submit" value="Login"></td>
</tr>

</table>
</form>
    <table border='1'>
<thead>
<th>id</th>
<th>username</th>
<th>password</th>
</thead>
</table>
</html>

